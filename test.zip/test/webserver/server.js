const express = require("express");
const app = express();
const port = 3000;
const fs = require("fs");

app.use(express.json());

let userData = require("./user.json");

app.listen(port, () => {
  console.log("Server is running on port " + port);
});

app.get("/getUsers", (req, res) => {
  const userId = parseInt(req.parasm.id);
  const user = userData.users.find((u) => u.Id === userID);

  if (user) {
    res.json(user);
  } else {
    res.status(404).json({ message: "User Not Found" });
  }
});

app.post("/addUser", (req, res) => {
  const newUser = req.body;
  newUser.id = userData.user.length + 1;
  userData.users.push(newUser);

  fs.writeFileSync("./user.json", JSON.stringify(userData, null, 2), "utf-8");

  res.status(200).json(newUser);
});
